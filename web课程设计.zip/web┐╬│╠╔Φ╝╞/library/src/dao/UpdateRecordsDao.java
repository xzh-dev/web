package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dbc.DataBaseConnection;
import vo.Records;

public class UpdateRecordsDao {
	private Connection con =null;
	private PreparedStatement pst = null;
	
	public UpdateRecordsDao(){
		super();	
		this.con =  new DataBaseConnection().getConnection();
	}
	
	public boolean insertRecords(String borowtime,String bookid,String stilltime,String uid){
		boolean result = false;
		String sql = "insert into takerecords(bookid,stilltime,borowtime,userid)"
				+ "  values(?,?,?,?)";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, bookid);
			pst.setString(2, stilltime);
			pst.setString(3, borowtime);
			pst.setString(4, uid);
			if(pst.executeUpdate()>0)
			{
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public ArrayList<Records> findAlluserBook(int uid , int num1,int num2){
		ArrayList<Records> list = new ArrayList<Records>(); 
		ResultSet rs = null; 
		String sql = "select a.stilltime ,c.bookName,a.borowtime,b.user_name from takerecords a,tuser b,tbook c "
				+ "  where a.userid = ? and b.user_id = a.userid  and c.id = a.bookid"; 
		sql += " limit ?,?";
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, uid);
			pst.setInt(2, num1);
			pst.setInt(3, num2);
			rs = pst.executeQuery();
			while(rs.next())
			{
				Records book = new Records();
				book.setStillTime(rs.getString(1));
				book.setBookName(rs.getString(2));
				book.setBorowTime(rs.getString(3));
				book.setUserName(rs.getString(4));
				list.add(book);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;				
	}
	
	public int findcount(String uid){
		int count=0;
		ResultSet rs = null; 
		String sql = "select * from takerecords where userid = ? ";
		try {			
			pst = con.prepareStatement(sql);
			pst.setString(1,uid);
			rs = pst.executeQuery();
			while(rs.next())
			{
				count++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;	
	}
	
	public void close(){
		try {
			this.pst.close();
			this.con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
}
