package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dbc.DataBaseConnection;
import vo.Book;


public class CRUDBookDao {
	private Connection con =null;
	private PreparedStatement pst = null;
	
	public CRUDBookDao(){
		super();	
		this.con =  new DataBaseConnection().getConnection();
	}
	public ArrayList<Book> finAllBook(int num1,int num2){
		ArrayList<Book> list = new ArrayList<Book>();
		ResultSet rs = null; 
		String sql = "select * from tbook";
		sql += " limit ?,?";
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, num1);
			pst.setInt(2, num2);
			rs = pst.executeQuery();
			while(rs.next())
			{
				Book book = new Book();
				book.setId(rs.getString(1));
				book.setBookName(rs.getString(2));
				book.setStore(rs.getString(3));
				list.add(book);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;				
	}
	
	public int finAllBook(){
		int count=0;
		ResultSet rs = null; 
		String sql = "select * from tbook";
		try {
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();
			while(rs.next())
			{
				count++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;	
	}
	public boolean updateStore(String bookid,int flag)
	{
		boolean result = false;
		String sql = "";
		if(flag==0){sql = "update  tbook SET store = store-1  where id = ? ";}
		else{sql = "update  tbook SET store = store+1  where id = ? ";}
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, bookid);
			if(pst.executeUpdate()>0)
			{
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	public void close(){
		try {
			this.pst.close();
			this.con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
}
