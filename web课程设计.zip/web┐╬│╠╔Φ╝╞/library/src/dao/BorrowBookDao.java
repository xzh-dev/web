package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dbc.DataBaseConnection;
import vo.UserBook;

public class BorrowBookDao {
	private Connection con =null;
	private PreparedStatement pst = null;
	
	public BorrowBookDao(){
		super();	
		this.con =  new DataBaseConnection().getConnection();
	}
	
	public boolean findBorrow(String userid,String bookid){
		boolean result = true;
		String sql = "select * from userbook where userid = ? and  bookid = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, userid);
			pst.setString(2, bookid);
			ResultSet rs = pst.executeQuery();		
			if(rs.next()){result = false;}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean insertBorrow(String userid,String bookid,String borowtime){
		boolean result = false;
		String sql = "insert into userbook(userid,bookid,borowtime)"
				+ " values(?,?,?)";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, userid);
			pst.setString(2, bookid);
			pst.setString(3, borowtime);
			if(pst.executeUpdate()>0)
			{
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean deleteBorrow(String userid,String bookid)
	{
		boolean result = false;
		String sql = "delete from userbook where userid = ? and bookid = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, userid);
			pst.setString(2, bookid);
			if(pst.executeUpdate()>0)
			{
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public ArrayList<UserBook> findAlluserBook(int uid , int num1,int num2){
		ArrayList<UserBook> list = new ArrayList<UserBook>(); 
		ResultSet rs = null; 
		String sql = "select c.id ,c.bookName,a.borowtime,b.user_name,b.user_id from userbook a,tuser b,tbook c "
				+ "  where a.userid = ? and b.user_id = a.userid  and c.id = a.bookid"; 
		sql += " limit ?,?";
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, uid);
			pst.setInt(2, num1);
			pst.setInt(3, num2);
			rs = pst.executeQuery();
			while(rs.next())
			{
				UserBook book = new UserBook();
				book.setBookid(rs.getString(1));
				book.setBookName(rs.getString(2));
				book.setBorowTime(rs.getString(3));
				book.setUserid(rs.getString(5));
				book.setUserName(rs.getString(4));
				list.add(book);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;				
	}
	
	public int findcount(String uid){
		int count=0;
		ResultSet rs = null; 
		String sql = "select * from userbook where userid = ? ";
		try {			
			pst = con.prepareStatement(sql);
			pst.setString(1,uid);
			rs = pst.executeQuery();
			while(rs.next())
			{
				count++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return count;	
	}
	
	public void close(){
		try {
			this.pst.close();
			this.con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
}
