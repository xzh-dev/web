package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbc.DataBaseConnection;
import vo.User;

public class Userdao {
	
	private Connection con =null;
	private PreparedStatement pst = null;
	
	public Userdao()
	{
		this.con =  new DataBaseConnection().getConnection();
	}
	
	
	
	public User getUserById(String id) throws SQLException {
		String sql = "select * from tuser where user_name = ?";	
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, id);
			 ResultSet rs = pst.executeQuery();		
			if(rs.next())
			{	
				User user = new User();
				user.setUserId(rs.getString(1));
				user.setUserName(rs.getString(2));
				user.setPassword(rs.getString(3));
	        	rs.close();
				return user;
			}
			else{
				rs.close();
			}
		} catch (SQLException e) {		
			e.printStackTrace();
		}  
		return null;
	}
	
	public boolean updatepsd(String uid,String psd)
	{
		boolean result = false;
		String sql = "";
		sql = "update  tuser SET user_psd = ?  where user_name = ? ";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, psd);
			pst.setString(2, uid);
			if(pst.executeUpdate()>0)
			{
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	public void close(){
		try {
			this.pst.close();
			this.con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
}
