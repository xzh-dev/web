package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import dao.BorrowBookDao;
import net.sf.json.JSONObject;
import vo.UserBook;


/**
 * Servlet implementation class QueryUserBook
 */
@WebServlet("/QueryUserBook.do")
public class QueryUserBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueryUserBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		
		String offset = request.getParameter("offset");
		String limit = request.getParameter("limit");
		String uid = request.getParameter("uid");
		Date date = null;
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		BorrowBookDao dao = new BorrowBookDao();
		ArrayList<UserBook> list = dao.findAlluserBook(Integer.parseInt(uid),Integer.parseInt(offset), Integer.parseInt(limit));
        for(int i = 0;i< list.size();i++)
        {
        	try {
				date = fmt.parse(list.get(i).getBorowTime()); //转换成指定的日期形式
				list.get(i).setBorowTime(fmt.format(date));  //转换成字符串
			} catch (ParseException e) {
				e.printStackTrace();
			}
        }
		if(list != null)
		{
			int total = dao.findcount(uid);
			String rowList = new Gson().toJson(list);
			String x = "{rows:" + rowList + ",total:" + total + "}";
			JsonObject userList = new JsonParser().parse(x).getAsJsonObject();
			out.print(new Gson().toJson(userList)); 
		}
		dao.close();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
