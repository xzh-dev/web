package vo;

public class Records {
	private String bookName;
	private String borowTime;
	private String stillTime;
	private String userName;
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBorowTime() {
		return borowTime;
	}
	public void setBorowTime(String borowTime) {
		this.borowTime = borowTime;
	}
	public String getStillTime() {
		return stillTime;
	}
	public void setStillTime(String stillTime) {
		this.stillTime = stillTime;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
}
