
	$(document).ready(function () {		
		getSession();
		records();
		toastr.options = {
				"positionClass":"toast-top-center",  //窗口显示位置
				"timeOut": "2000",
		}
	});
	
	function records(){
		$('#records').bootstrapTable('destroy');  
	    $("#records").bootstrapTable({
	        url: 'QueryRecords.do',    //请求后台的URL（*）
	        method: 'GET',                      //请求方式（*）
			locale: 'zh-CN',
	        toolbar: '#toolbar',                //工具按钮用哪个容器
	        striped: true,                      //是否显示行间隔色  
	        cache: false,                       //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
	        pagination: true,                   //是否显示分页（*）
	        sortable: true,                     //是否启用排序
	        sortOrder: "asc",                   //排序方式  asc升序 desc降序
	        sortName :"CarPlaceNum",            //排序字段名
	        sidePagination: "server",           //分页方式：client客户端分页，server服务端分页（*）
	        pageNumber:1,                       //初始化加载第一页，默认第一页
	        pageSize:8,                       //每页的记录行数（*） 
	        pageList: [8,10,25,50,100],          //可供选择的每页的行数（*）
	        //search: true,                       //是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
	        strictSearch: true,
	        showColumns: true,                  //是否显示所有的列
	        showRefresh: true,                  //是否显示刷新按钮
	        queryParamsType : "limit",
	        queryParams: function(params) {//上传服务器的参数
	            var temp = {
	            		offset: params.offset,//从数据库第几条记录开始  
	                    limit: params.limit,//找多少条  
	                    uid:$(".span2").prop("id")
	                };
	                return temp;
	            },  
	        //showExport: true,                   //是否显示输出
	        minimumCountColumns: 2,             //最少允许的列数
	        clickToSelect: true,                //是否启用点击选中行
	       // height: 500,                        //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
	        uniqueId: "ID",                     //每一行的唯一标识，一般为主键列
	        showToggle:false,                    //是否显示详细视图和列表视图的切换按钮
	        cardView: false,                    //是否显示详细视图
	        detailView: false,                   //是否显示父子表       
	        responseHandler: function (result) {  
	            var temp = {
	                // 下面这两个参数是必须有的, 名称不能变
	                // 总的数量
	                total : result.total,
	                //total:5,
	                // 数据
	                rows : result.rows,	             
//	                 rows:[{id:'1',bookName:'《三国演义》',store:'100'},
//	                      {id:'2',bookName:'《西游记》',store:'120'},
//	                      {id:'3',bookName:'《钢铁时怎样练成的》',store:'150'}] 
	            };
	            return temp;
	        }, // 请求成功后,渲染表格
	        columns : [
	        {
	            field: 'bookName',
	            title: '书名',
	            align: 'center'
	        }, {
	            field: 'borowTime',
	            title: '借阅时间',
	            align: 'center'
	        }, {
	            field: 'stillTime',
	            title: '归还时间',
	            align: 'center'
	        }, {
	            field: 'userName',
	            title: '借阅人',
	            align: 'center'
	        }]
	    })
	}