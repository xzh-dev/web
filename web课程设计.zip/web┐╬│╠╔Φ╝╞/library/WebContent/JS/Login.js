
$(document).ready(function () {
	//初始化toastr
	toastr.options = {
			"positionClass":"toast-top-center",  //窗口显示位置
			"timeOut": "2000", 
	}
	getCookie(); //检查本地是否有cookie如果有cookie就自动登陆 
}
);

/*登陆数据校验*/
$("#userName").blur(function(){
	if($("#userName").val() == "" || $("#userName").val() == null) 			
		$("#error_Username").html("用户名不能为空！");	
	else
		$("#error_Username").html(""); 
});
$("#password").blur(function(){
	if($("#password").val() == "" || $("#password").val() == null) 
		$("#error_Userpsd").html("密码不能为空！");
	else
		$("#error_Userpsd").html(""); 
});
$("#VerificationCode").blur(function(){
	if($("#VerificationCode").val() == "" || $("#VerificationCode").val() == null) 
		$("#error_yzm").html("验证码不能为空！");
	else
		$("#error_yzm").html(""); 
});
/*
 * 密码的显示与隐藏
 */
$("#lookPsd").click(function(){
	if($("#NewModelpsd2").attr("type") == "password")
		$("#NewModelpsd2").attr("type","text");
	else
		$("#NewModelpsd2").attr("type","password");
});
$("#lookpsd").click(function(){
	if($("#NewModelPsd").attr("type") == "password")
		$("#NewModelPsd").attr("type","text");
	else
		$("#NewModelPsd").attr("type","password");
});

function setCookie() {
    var userName = $("#userName").val(); // 用户名
    var passWord = $("#password").val(); //密码
    var cookieName = 'userInfo' ;// cookie名称
    var data = {
        username: userName,
        password: passWord
    };
    var d = new Date();
    var saveTime = 7;// cookie保存时间（单位：天）
    d.setDate(d.getDate() + saveTime);
    document.cookie = cookieName + '=' + JSON.stringify(data) + ';expires=' + d.toGMTString();
}  


function getCookie() {
    var cookie = document.cookie;
    var cookieName = 'userInfo' ;// cookie名称
    var arr = cookie.split('; '); // 将cookie信息和时间戳拆分为数组
    var userInfo = null;
    for (var i = 0; i < arr.length; i++) {
        var tempArr = arr[i].split('='); // 将cookie名称和data拆分开，分别是数组的第一个元素和第二个元素
        if (tempArr[0] === cookieName) {
            userInfo = JSON.parse(tempArr[1]);
        }
    }
    var obj = eval(userInfo);
     
    //console.log(obj);  
    
    if (userInfo) {
		 $.ajax({
	            type: "POST",
	            url: "Login.do",
	            contentType: "application/x-www-form-urlencoded;charset=utf-8",
	            data:{userName:obj.username,password:obj.password,VerificationCode:'0'},
	            dataType: "text",	           
	            success: function (data) {  
	            	if(data == "success")
	            		{
	            			window.location.href = "main.html";   
	            		}	            		          			            	
	            },
	            error: function (error) {
	                alert("请求后台失败！");
	            }
	})
        //console.log(); 
    }
}
 

	$("#btn_login").click(function(){
		 $.ajax({
	            type: "POST",
	            url: "Login.do",
	            contentType: "application/x-www-form-urlencoded;charset=utf-8",
	            data:{userName:$("#userName").val(),password:$("#password").val(),VerificationCode:$("#VerificationCode").val()},
	            dataType: "text",	           
	            success: function (data) { 
	            	if(data != "success")
	            		{
	            			toastr.error(data);  
	            		}
	            	else{
	            		if( $('#checkbox').is(':checked'))
	            			{
	            				setCookie(); //如果勾选就设置cookie
	            			}         			
	            		window.location.href = "main.html";            		
	            	}
	            },
	            error: function (error) {
	                alert("error=" + error);
	            }
	})
	});


      var img = $("#yzmimg");
      //console.log("img", img)
      img.click(function(){
        img.attr('src', '/library/CreateVCodeImageController.do?t=' + Math.random());
      });


var index = 1;
var timer;
timer = setInterval(function () {
index%=5;
$("body").css("transition","none");
$("body").css("background-image","url(img/login" + index+ ".jpg)"); 
$("body").css("transition","all 3s ease");
index++;
},4500);

