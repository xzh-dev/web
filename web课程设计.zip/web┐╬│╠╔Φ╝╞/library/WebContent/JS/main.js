
var currentUser;

	$("#MyBorrow").click(function(e){		
        $.ajax({
            type: "GET",
            url: "JumpMyBorrow.do",
            //contentType: "application/json; charset=utf-8",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
    		//data:{'按钮':$(this).attr("value")}, 
            dataType: "html",
            success: function (data) { 
            	$(".content").html(data);
            },
            error: function (error) {
                alert("error=" + error);
            }
        });
	});	
	
	$("#about").click(function(){
		$("#myModal").modal("show");
		$("#UpdateModelUserName").attr("value",currentUser.userName);
	})
	$("#btn_updateUser").click(function(){
        $.ajax({
            type: "GET",
            url: "UpdateUser.do",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
    		data:{'oldpsd':$("#oldpsd").val(),'newpsd':$("#newpsd").val(),'uid':$("#UpdateModelUserName").val()}, 
            dataType: "text",
            success: function (data) { 
            	if(data == "success"){
            		toastr.success("修改成功！");
                	$("#myModal").modal("hide");
            	}
            	else if(data == "psderror")
            		{toastr.warning("密码错误！");}
            	else{toastr.error("修改失败！");}
            },
            error: function (error) {
                alert("error=" + error);
            }
        });
	})	
	
	$("#BorrowRecords").click(function(e){		
        $.ajax({
            type: "GET",
            url: "JumpBorrowRecords.do",
            //contentType: "application/json; charset=utf-8",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
    		//data:{'按钮':$(this).attr("value")}, 
            dataType: "html",
            success: function (data) { 
            	$(".content").html(data);
            },
            error: function (error) {
                alert("error=" + error);
            }
        });
	});
	$("#main").click(function(){
		window.location.href = "main.html";
	});
	function InitBookTable(){
		 
		$('#BookTable').bootstrapTable('destroy');  
	    $("#BookTable").bootstrapTable({
	        url: 'QueryBook.do',    //请求后台的URL（*）
	        method: 'GET',                      //请求方式（*）
			locale: 'zh-CN',
	        toolbar: '#toolbar',                //工具按钮用哪个容器
	        striped: true,                      //是否显示行间隔色  
	        cache: false,                       //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
	        pagination: true,                   //是否显示分页（*）
	        sortable: true,                     //是否启用排序
	        sortOrder: "asc",                   //排序方式  asc升序 desc降序
	        sortName :"CarPlaceNum",            //排序字段名
	        sidePagination: "server",           //分页方式：client客户端分页，server服务端分页（*）
	        pageNumber:1,                       //初始化加载第一页，默认第一页
	        pageSize:8,                       //每页的记录行数（*） 
	        pageList: [8,10,25,50,100],          //可供选择的每页的行数（*）
	        //search: true,                       //是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
	        strictSearch: true,
	        showColumns: true,                  //是否显示所有的列
	        showRefresh: true,                  //是否显示刷新按钮
	        queryParamsType : "limit",
	        queryParams: function(params) {//上传服务器的参数
	            var temp = {
	            		offset: params.offset,//从数据库第几条记录开始  
	                    limit: params.limit,//找多少条  
	                    //搜索按钮的参数
	                    //data:datas,
	                    //排序参数
	                    //sortName:this.sortName,
	                    //sortOrder:this.sortOrder
	                };
	                return temp;
	            },  
	        //showExport: true,                   //是否显示输出
	        minimumCountColumns: 2,             //最少允许的列数
	        clickToSelect: true,                //是否启用点击选中行
	       // height: 500,                        //行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
	        uniqueId: "ID",                     //每一行的唯一标识，一般为主键列
	        showToggle:false,                    //是否显示详细视图和列表视图的切换按钮
	        cardView: false,                    //是否显示详细视图
	        detailView: false,                   //是否显示父子表       
	        responseHandler: function (result) {  
	            var temp = {
	                // 下面这两个参数是必须有的, 名称不能变
	                // 总的数量
	                total : result.total,
	                //total:5,
	                // 数据
	                rows : result.rows
	                /* rows:[{'id':'1','bookName':'《三国演义》','store':'100'},
	                      {id:'2',bookName:'《西游记》',store:'120'},
	                      {id:'3',bookName:'《钢铁时怎样练成的》',store:'150'}] */
	            };
	            return temp;
	        }, // 请求成功后,渲染表格
	        columns : [{
	            checkbox: true                //全选按钮
	        }, {
	            field: 'id',               
	            title: '图书编号',
	            align: 'center'
	        }, {
	            field: 'bookName',
	            title: '书名',
	            align: 'center'
	        }, {
	            field: 'store',
	            title: '库存',
	            align: 'center'
	        }, {
	            field: 'opotion',
	            title: '操作',
	            align: 'center',
	            formatter: operateFormatter    
	        }]
	    })
	}

	function operateFormatter(value,row,index){
		 return '<button  type="button" onClick="borrow('+row.id+","+row.store+')"  class="btn btn-primary" data-toggle="modal" data-target="#consumeModal">借阅</button>';
	}

	$(document).ready(function () {		
		getSession();
		InitBookTable();
		toastr.options = {
				"positionClass":"toast-top-center",  //窗口显示位置
				"timeOut": "2000",
		}
	});

	function borrow(id,store){
		if(store==0)
			{
				toastr.warning("库存不足！");
				return;
			}
		var uid = currentUser.userId;
        $.ajax({
            type: "GET",
            url: "InsertMyBorrow.do",
            //contentType: "application/json; charset=utf-8",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
    		data:{'userid':uid,'bookid':id}, 
            dataType: "text",
            success: function (data) {
            	if(data == "success")
            		{
            			toastr.success("借阅成功！");
            			updatestore(id,0);
            		}
            	else if(data == "error")
            		{toastr.error("借阅失败！");}
            	else{toastr.warning(data);}
            },
            error: function (error) {
                alert("error=" + error);
            }
        });
	}
	
	function updatestore(id,flag){
		//0借阅，1归还
        $.ajax({
            type: "GET",
            url: "UpdateStore.do",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
    		data:{'bookid':id,'flag':flag}, 
            dataType: "text",
            success: function (data) {
            	$('#BookTable').bootstrapTable('refresh'); 
            },
            error: function (error) {
                alert("error=" + error);
            }
        });	
	}
	
	function getSession(){
        $.ajax({
            type: "GET",
            url: "Login.do",
            //contentType: "application/json; charset=utf-8",
            contentType: "application/x-www-form-urlencoded;charset=utf-8",
    		//data:{'按钮':$(this).attr("value")}, 
            dataType: "json",
            success: function (data) {
            	currentUser = data;
            	$(".span2").html("欢迎您："+data.userName);
            	$(".span2").attr("id",data.userId);
            	//console.log(currentUser.userId);
            },
            error: function (error) {
                alert("error=" + error);
            }
        });
	}

	$("#nav li").click(function (e) {
		e.preventDefault();
		$("#nav li").children().attr("class","");
	    $(this).children().attr("class","active");       	   
	});