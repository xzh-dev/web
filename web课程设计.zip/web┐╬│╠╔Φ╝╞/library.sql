/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50728
Source Host           : localhost:3306
Source Database       : library

Target Server Type    : MYSQL
Target Server Version : 50728
File Encoding         : 65001

Date: 2020-12-15 23:02:30
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for takerecords
-- ----------------------------
DROP TABLE IF EXISTS `takerecords`;
CREATE TABLE `takerecords` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `borowtime` datetime DEFAULT NULL,
  `bookid` int(11) DEFAULT NULL,
  `stilltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of takerecords
-- ----------------------------
INSERT INTO `takerecords` VALUES ('4', '1', '2020-12-15 21:35:40', '2020121502', '2020-12-15 21:35:49');
INSERT INTO `takerecords` VALUES ('5', '1', '2020-12-15 20:50:49', '2020121504', '2020-12-15 21:37:15');
INSERT INTO `takerecords` VALUES ('6', '1', '2020-12-15 20:26:13', '2020121503', '2020-12-15 22:04:34');
INSERT INTO `takerecords` VALUES ('7', '1', '2020-12-15 22:04:48', '2020121506', '2020-12-15 22:06:36');
INSERT INTO `takerecords` VALUES ('8', '1', '2020-12-15 21:04:47', '2020121508', '2020-12-15 22:06:40');
INSERT INTO `takerecords` VALUES ('9', '1', '2020-12-15 21:25:29', '2020121501', '2020-12-15 22:10:47');
INSERT INTO `takerecords` VALUES ('10', '1', '2020-12-15 22:10:51', '2020121501', '2020-12-15 22:10:54');
INSERT INTO `takerecords` VALUES ('11', '1', '2020-12-15 22:06:55', '2020121511', '2020-12-15 22:42:27');
INSERT INTO `takerecords` VALUES ('12', '1', '2020-12-15 22:06:53', '2020121513', '2020-12-15 22:42:28');
INSERT INTO `takerecords` VALUES ('13', '1', '2020-12-15 22:08:06', '2020121510', '2020-12-15 22:42:29');

-- ----------------------------
-- Table structure for tbook
-- ----------------------------
DROP TABLE IF EXISTS `tbook`;
CREATE TABLE `tbook` (
  `id` int(11) DEFAULT NULL,
  `bookName` varchar(255) DEFAULT NULL,
  `store` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbook
-- ----------------------------
INSERT INTO `tbook` VALUES ('2020121501', '《三国演义》', '100');
INSERT INTO `tbook` VALUES ('2020121502', '《钢铁时怎样炼成的》', '99');
INSERT INTO `tbook` VALUES ('2020121503', '《平凡的世界》', '149');
INSERT INTO `tbook` VALUES ('2020121504', '《海底两万里》', '119');
INSERT INTO `tbook` VALUES ('2020121505', '《资治通鉴》', '119');
INSERT INTO `tbook` VALUES ('2020121506', '《城南旧事》', '134');
INSERT INTO `tbook` VALUES ('2020121507', '《骆驼祥子》', '0');
INSERT INTO `tbook` VALUES ('2020121508', '《孙子兵法》', '47');
INSERT INTO `tbook` VALUES ('2020121509', '《史记》', '76');
INSERT INTO `tbook` VALUES ('2020121510', '《呐喊》', '70');
INSERT INTO `tbook` VALUES ('2020121511', '《一千零一夜》', '86');
INSERT INTO `tbook` VALUES ('2020121512', '《时间简史》', '98');
INSERT INTO `tbook` VALUES ('2020121513', '《堂吉诃德》', '210');
INSERT INTO `tbook` VALUES ('2020121514', '《伊索寓言》', '46');

-- ----------------------------
-- Table structure for tuser
-- ----------------------------
DROP TABLE IF EXISTS `tuser`;
CREATE TABLE `tuser` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT NULL,
  `user_psd` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tuser
-- ----------------------------
INSERT INTO `tuser` VALUES ('1', 'xzh', 'xzh123');
INSERT INTO `tuser` VALUES ('2', 'zwb', 'zwb123');

-- ----------------------------
-- Table structure for userbook
-- ----------------------------
DROP TABLE IF EXISTS `userbook`;
CREATE TABLE `userbook` (
  `userid` int(11) DEFAULT NULL,
  `bookid` int(11) DEFAULT NULL,
  `borowtime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of userbook
-- ----------------------------
INSERT INTO `userbook` VALUES ('1', '2020121505', '2020-12-15 19:26:16');
INSERT INTO `userbook` VALUES ('1', '2020121504', '2020-12-15 21:37:19');
INSERT INTO `userbook` VALUES ('1', '2020121502', '2020-12-15 22:04:38');
INSERT INTO `userbook` VALUES ('1', '2020121509', '2020-12-15 22:06:49');
INSERT INTO `userbook` VALUES ('1', '2020121503', '2020-12-15 22:08:15');
INSERT INTO `userbook` VALUES ('1', '2020121506', '2020-12-15 22:08:42');
INSERT INTO `userbook` VALUES ('1', '2020121508', '2020-12-15 22:10:37');
